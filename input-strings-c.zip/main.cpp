#include<iostream>
using namespace std;
int main(){
    string s;
    cin>>s;
    cout<<"the required text is: "<<s;
    return 0;
}