#include<iostream>
using namespace std;
int main(){
    int marks = 59;
    if(marks<=25){
        cout<<"fail"<<endl;
    }else if(marks>=25&&marks<=44){
        cout<<"Grade:E"<<endl;
    }else if(marks>=45&&marks<=49){
        cout<<"Grade:D"<<endl;
    }else if(marks>=50&&marks<=59){
        cout<<"Grade:C"<<endl;
    }else if(marks>=60&&marks<=69){
        cout<<"Grade:B"<<endl;
    }else if(marks>=70){
        cout<<"Grade:A"<<endl;
    }
    return 0;
}